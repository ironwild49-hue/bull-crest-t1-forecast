#!/usr/bin/env python3
"""Operational daily runner for Bull & Crest T+1."""
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parent

def run(mode):
    if mode == "score":
        cmd=[sys.executable,str(ROOT/"t1_market_forecast_final.py"),"score"]
    else:
        # Score completed prior forecasts first, then refresh universe/data and forecast next session.
        subprocess.run([sys.executable,str(ROOT/"t1_market_forecast_final.py"),"score"], cwd=ROOT, check=False)
        cmd=[sys.executable,str(ROOT/"t1_market_forecast_final.py"),"auto-scan","--refresh-data"]
    print("RUN:", " ".join(cmd))
    return subprocess.run(cmd, cwd=ROOT, check=False).returncode

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "forecast"
    raise SystemExit(run(mode))
