# BULL & CREST — T+1 MARKET FORECAST SYSTEM v2.1

A research-grade workflow for: **NSE universe → opportunity scan → T+1 statistical forecast → historical analogs → technical confluence → prediction ranges → scenarios → persistent forecast ledger → next-day scoring → walk-forward validation.**

This is not a guaranteed predictor or trading signal. Probabilities are model estimates until sufficient out-of-sample evidence supports calibration.

## 1. Daily workflow

**15:40–15:45 IST:** scan the available NSE universe, rank candidates, generate detailed T+1 forecasts, and record them in `T1_FORECAST_LEDGER.csv`.

**09:25 IST:** validate the previous forecast against the opening session when the workflow is being run operationally.

**After the target session:** run `score` to attach actual OHLCV, forecast errors, range hits, scenario result, and failure classification to the ledger.

The system does not require a manually selected stock list for the normal scan workflow.

## 2. Core commands

Install:
```bash
pip install pandas numpy scikit-learn yfinance
```

Scan an NSE universe and record forecasts:
```bash
python t1_market_forecast_final.py scan --universe universe.csv --record-ledger
```

Forecast selected symbols and record them:
```bash
python t1_market_forecast_final.py forecast --symbols RELIANCE,TCS,HDFCBANK --record-ledger
```

Score pending ledger forecasts after actual target-day data is available:
```bash
python t1_market_forecast_final.py score
```

Historical walk-forward validation:
```bash
python t1_market_forecast_final.py backtest --symbol RELIANCE
```

## 3. Important v2.1 correction

The previous v2.0 engine incorrectly used the last supervised row as the current forecast state. Because the final supervised row is the last day whose next-session target is already known, this could misalign the forecast with the current market close.

v2.1 now uses:

**all historical rows with known next-session outcomes → train**

and

**latest actual trading-day feature state → T+1 forecast**

Walk-forward validation also uses positional next-session lookup rather than timestamp arithmetic.

## 4. Prediction ranges

50% and 80% intervals now use **temporal out-of-sample calibration residuals** from a later calibration slice of the training history rather than residuals from the same observations used to fit the final model.

They are prediction intervals, not guaranteed support/resistance.

## 5. Probability discipline

The output explicitly labels probabilities as **MODEL ESTIMATE — NOT CALIBRATED** until sufficient out-of-sample evidence supports calibration.

Confluence is a ranking score, not a probability.

## 6. Forecast ledger

`T1_FORECAST_LEDGER.csv` is the persistent record. Forecasts are never deleted because they were wrong.

It records forecast date, target date, reference close, OHLCV forecasts, 50%/80% ranges, probability estimates, technical state, confluence, scenarios, and—after scoring—actual OHLCV, errors, range hits, scenario result and failure classification.

## 7. Review / model-update policy

- **First 3 trading days:** review only. Do not redesign the model.
- **After ~1–2 weeks:** meaningful recalibration review if enough observations exist.
- **50+ forecasts:** serious statistical evaluation.
- Never claim improvement without evidence.
- Compare old vs new performance when methodology changes.

## 8. Current universe limitation

The included `universe_template.csv` is only a small example universe. A complete NSE scan requires a maintained full NSE symbol file. The engine will scan whatever universe file is supplied; it does not fabricate missing symbols.

## 9. Persistent project artifacts

- `t1_market_forecast_final.py` — master engine
- `T1_FORECAST_LEDGER.csv` — persistent forecast/results ledger
- `T1_FORECAST_CONFIG.json` — configuration and review policy
- `T1_FORECAST_CHANGELOG.md` — methodology/code change history
- `T1_BACKTEST_RESULTS.json` — latest backtest result artifact
- `universe_template.csv` — example universe

The original v2.0 engine is preserved as `t1_market_forecast_final_v2_0_legacy.py` for traceability.

## 10. Operational v2.2 data/execution layer

The operational path is now:

**NSE official equity universe -> 6-month batch OHLCV prefetch -> liquidity/data-quality scan -> market-regime context -> top scanner candidates -> 3-year full-history T+1 model -> ledger**

### Automatic NSE universe
The engine can refresh the official NSE equity-segment security list with:
```bash
python t1_market_forecast_final.py auto-scan --refresh-data
```

The official NSE page publishes the Equity-segment CSV; the engine uses that list rather than the small example `universe_template.csv` when `auto-scan` is used.

### Daily machine execution
Install dependencies:
```bash
pip install -r requirements.txt
```
Then schedule:
```bash
python run_t1_daily.py
```

`run_t1_daily.py` first scores pending prior forecasts and then performs a fresh automatic scan/forecast. It is intended for cron, Windows Task Scheduler, or another always-on execution environment with internet access.

### Data-source boundary
The ChatGPT conversation task is a reporting/notification layer; it does not execute the ZIP's local Python process itself. For a genuinely automatic end-to-end model run, the Python runner must execute on an internet-connected machine/server. If the runner cannot obtain fresh data, it must fail/report rather than fabricate forecasts.

### Cache policy
`T1_DATA_CACHE/` is a resilience cache. Operational runs use fresh downloads when requested; cached data is only a fallback when fresh retrieval is unavailable. The run status is written to `T1_RUN_STATUS.json`.

### Cloud execution option
A GitHub Actions workflow is included at `.github/workflows/t1_daily.yml`. After placing the project in a repository, GitHub can run the Python engine on a weekday schedule without the user's PC being on. The workflow commits the ledger/run artifacts back to the repository. A repository/CI environment is required; ChatGPT's scheduled task by itself is not a Python execution server.
