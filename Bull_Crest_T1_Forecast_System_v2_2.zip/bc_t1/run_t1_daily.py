#!/usr/bin/env python3
"""Operational daily runner for Bull & Crest T+1.

Designed for cron/Task Scheduler on a machine with internet access.
It refreshes the NSE equity universe, downloads recent market data in batches,
forecasts the strongest candidates, records the ledger, and scores any pending
prior forecasts whose target-day data is now available.
"""
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parent

def run(*args):
    cmd=[sys.executable,str(ROOT/'t1_market_forecast_final.py'),*args]
    print('RUN:', ' '.join(cmd))
    return subprocess.run(cmd, cwd=ROOT, check=False).returncode

if __name__=='__main__':
    score_code=run('score')
    run_code=run('auto-scan','--refresh-data')
    raise SystemExit(run_code or score_code)
