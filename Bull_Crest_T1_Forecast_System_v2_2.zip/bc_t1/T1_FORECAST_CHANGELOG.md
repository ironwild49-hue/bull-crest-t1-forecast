# BULL & CREST — T+1 FORECAST CHANGELOG

## 2.1 — 2026-10-07

### Core fixes
- Corrected T+1 temporal alignment: the latest actual trading day's feature state is used to forecast the next session.
- Corrected walk-forward target indexing to use positional trading-session lookup.
- Added temporal out-of-sample calibration residuals for 50%/80% intervals.

### Operational additions
- Added persistent `T1_FORECAST_LEDGER.csv`.
- Added automatic forecast recording via `--record-ledger`.
- Added `score` mode for next-day actual scoring and failure classification.
- Added `T1_FORECAST_CONFIG.json` with review/recalibration/evaluation policy.
- Added persistent `T1_BACKTEST_RESULTS.json` output path.

### Policy
- First 3 trading days: review only; no model redesign.
- After roughly 1–2 weeks: meaningful recalibration review if enough observations exist.
- After 50+ forecasts: serious statistical evaluation.
- No change is an improvement without validation evidence.
- Historical forecast records are never deleted because they were wrong.

### Validation
- Python compilation passed.
- Synthetic structural tests are being used for temporal alignment and workflow verification before live-data validation.

## 2.0
Previous engine supplied in the original project ZIP. Preserved as `t1_market_forecast_final_v2_0_legacy.py`.

## 2.2 — 2026-10-07 — Operational data/execution upgrade

### Data layer
- Added automatic refresh of the official NSE equity-segment universe from NSE's published `EQUITY_L.csv`.
- Added a cached NSE universe fallback when the official list cannot be fetched.
- Added short-history (6-month) batch OHLCV prefetch for the broad universe to avoid one network request per stock during the first scan stage.
- Added local OHLCV cache for resilience and repeat runs.
- Added a 20-candidate full-history (3-year) second stage so expensive model fitting is reserved for the strongest scanner candidates.
- Added NIFTY-based market-regime context where data is available.
- Added median turnover quality filtering to the opportunity scanner.

### Execution
- Added `auto-scan` command for an end-to-end operational run: refresh NSE universe -> batch market data -> scan -> detailed T+1 forecast -> ledger.
- Added `run_t1_daily.py` for cron / Windows Task Scheduler execution.
- Added `requirements.txt` with the required data/ML dependencies.

### Safety
- No synthetic or fabricated market data is used when live data cannot be fetched.
- Cached data is explicitly a fallback; a run should report its data source/status.
- Existing v2.1 methodology remains the forecast layer; this release primarily supplies the missing operational data/execution layer.
