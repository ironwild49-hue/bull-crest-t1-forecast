#!/usr/bin/env python3
"""
BULL & CREST — T+1 MARKET FORECAST SYSTEM v2.2
Universe Scanner -> T+1 Forecast -> Ledger -> Next-day Scoring -> Walk-forward Validation

Research system only. Probabilities are model estimates until calibrated by sufficient
out-of-sample evidence. No guarantee, signal, or trading recommendation.
"""
from __future__ import annotations
import argparse, csv, json, math, os, time, warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")

try:
    import requests
except ImportError:
    requests = None
try:
    import yfinance as yf
except ImportError:
    yf = None
try:
    from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
except ImportError:
    RandomForestRegressor = RandomForestClassifier = None

ROOT = Path(__file__).resolve().parent
LEDGER = ROOT / "T1_FORECAST_LEDGER.csv"
CONFIG_FILE = ROOT / "T1_FORECAST_CONFIG.json"
CHANGELOG = ROOT / "T1_FORECAST_CHANGELOG.md"
BACKTEST_RESULTS = ROOT / "T1_BACKTEST_RESULTS.json"
DATA_DIR = ROOT / "T1_DATA_CACHE"
UNIVERSE_CACHE = ROOT / "T1_NSE_UNIVERSE.csv"
RUN_STATUS = ROOT / "T1_RUN_STATUS.json"
NSE_EQUITY_URL = "https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv"

@dataclass
class Config:
    history_period: str = "3y"
    scan_history_period: str = "6mo"
    min_history: int = 250
    min_scan_history: int = 60
    scan_top_n: int = 20
    final_top_n: int = 8
    min_avg_turnover_crore: float = 5.0
    universe_source: str = "NSE_EQUITY_L.csv"
    request_pause_seconds: float = 0.15
    refresh_data: bool = False
    batch_size: int = 100
    analog_k: int = 40
    rf_trees: int = 350
    min_train: int = 160
    backtest_start: int = 180
    calibration_fraction: float = 0.20
    calibration_min: int = 40
    ledger_path: str = str(LEDGER)

FEATURES = [
    "ret1","gap","range","body","upper_wick","lower_wick","ret_3","ret_5","ret_10","ret_20","ret_50",
    "vol_5","vol_10","vol_20","vol_50","volume_ratio_5","volume_ratio_10","volume_ratio_20","volume_ratio_50",
    "dist_sma_5","dist_sma_10","dist_sma_20","dist_sma_50","range_pos_10","range_pos_20","range_pos_50",
    "atr_pct_14","rsi14","trend_strength",
]

def load_config(path: Path = CONFIG_FILE) -> Config:
    cfg=Config()
    if not path.exists(): return cfg
    try:
        data=json.loads(path.read_text(encoding="utf-8"))
        aliases={"min_history_sessions":"min_history","final_candidates":"final_top_n"}
        for k,v in data.items():
            k=aliases.get(k,k)
            if hasattr(cfg,k): setattr(cfg,k,v)
        return cfg
    except Exception as e:
        print(f"[config-warning] {e}; using built-in defaults")
        return cfg

LEDGER_COLUMNS = [
    "forecast_id","forecast_date","target_date","symbol","reference_close","pred_open","pred_high","pred_low","pred_close","pred_volume",
    "open_50_low","open_50_high","open_80_low","open_80_high","high_50_low","high_50_high","high_80_low","high_80_high",
    "low_50_low","low_50_high","low_80_low","low_80_high","close_50_low","close_50_high","close_80_low","close_80_high",
    "volume_50_low","volume_50_high","volume_80_low","volume_80_high","up_probability_model","up_probability_analog","up_probability_estimate",
    "down_probability_estimate","probability_status","primary_bias","confluence_score","confidence_band","analog_count","technical_state_json","scenarios_json",
    "actual_open","actual_high","actual_low","actual_close","actual_volume","direction_result","open_error_pct","high_error_pct","low_error_pct","close_error_pct",
    "volume_error_pct","close_50_hit","close_80_hit","scenario_result","failure_classification","scored_at"
]

def require_ml():
    if RandomForestRegressor is None:
        raise RuntimeError("Install dependencies: pip install pandas numpy scikit-learn yfinance")

def _clean_ohlcv(df: pd.DataFrame, min_rows: int, symbol: str) -> pd.DataFrame:
    if df is None or df.empty: raise ValueError(f"No data returned for {symbol}")
    if isinstance(df.columns, pd.MultiIndex): df.columns = df.columns.get_level_values(0)
    df = df.rename(columns={c: str(c).lower() for c in df.columns})
    needed=["open","high","low","close","volume"]
    missing=[c for c in needed if c not in df.columns]
    if missing: raise ValueError(f"{symbol}: missing columns {missing}")
    df=df[needed].copy()
    for c in needed: df[c]=pd.to_numeric(df[c], errors="coerce")
    df=df.dropna(); df.index=pd.to_datetime(df.index).tz_localize(None); df=df[~df.index.duplicated(keep="last")].sort_index()
    if len(df)<min_rows: raise ValueError(f"{symbol}: only {len(df)} sessions; need at least {min_rows}")
    return df

def _cache_path(symbol: str, period: str) -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR / f"{symbol.replace('.','_')}_{period}.csv"

def load_symbol(symbol: str, cfg: Config, period: str | None = None, min_rows: int | None = None, refresh: bool = False) -> pd.DataFrame:
    if yf is None: raise RuntimeError("Install dependencies: pip install -r requirements.txt")
    period = period or cfg.history_period; min_rows = min_rows or cfg.min_history
    cp=_cache_path(symbol,period)
    refresh = bool(refresh or cfg.refresh_data)
    if cp.exists() and not refresh:
        try: return _clean_ohlcv(pd.read_csv(cp,index_col=0),min_rows,symbol)
        except Exception: pass
    df = yf.download(symbol, period=period, interval="1d", auto_adjust=False, progress=False, threads=False)
    df=_clean_ohlcv(df,min_rows,symbol)
    df.to_csv(cp)
    if cfg.request_pause_seconds: time.sleep(cfg.request_pause_seconds)
    return df

def prefetch_universe_scan_data(universe: List[str], cfg: Config) -> dict:
    """Batch-download short-history data so an NSE-wide scan does not make one request per symbol."""
    if yf is None: raise RuntimeError("Install dependencies: pip install -r requirements.txt")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    fetched=0; failed=0
    for start in range(0,len(universe),cfg.batch_size):
        batch=universe[start:start+cfg.batch_size]
        try:
            raw=yf.download(batch,period=cfg.scan_history_period,interval="1d",auto_adjust=False,progress=False,threads=True,group_by="ticker")
            if isinstance(raw.columns,pd.MultiIndex):
                level0=set(str(x) for x in raw.columns.get_level_values(0))
                # yfinance may return (field,ticker) or (ticker,field); normalize by detecting OHLCV field names.
                fields={"Open","High","Low","Close","Volume"}
                if fields.intersection(level0): raw=raw.swaplevel(0,1,axis=1).sort_index(axis=1)
                for ticker in batch:
                    if ticker not in raw.columns.get_level_values(0): continue
                    sub=raw[ticker].copy()
                    try:
                        sub=_clean_ohlcv(sub,cfg.min_scan_history,ticker); sub.to_csv(_cache_path(ticker,cfg.scan_history_period)); fetched+=1
                    except Exception: failed+=1
            else:
                # Single-symbol batch fallback.
                if len(batch)==1:
                    sub=_clean_ohlcv(raw,cfg.min_scan_history,batch[0]); sub.to_csv(_cache_path(batch[0],cfg.scan_history_period)); fetched+=1
        except Exception as e:
            print(f"[batch-download-skip] batch {start+1}-{start+len(batch)}: {e}"); failed+=len(batch)
    return {"requested":len(universe),"cached":fetched,"failed":failed}

def refresh_nse_universe(path: Path = UNIVERSE_CACHE) -> List[str]:
    if requests is None: raise RuntimeError("Install requests: pip install -r requirements.txt")
    headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36","Accept":"text/csv,application/octet-stream,*/*","Referer":"https://www.nseindia.com/"}
    r=requests.get(NSE_EQUITY_URL,headers=headers,timeout=30); r.raise_for_status()
    from io import StringIO
    df=pd.read_csv(StringIO(r.text))
    cols={c.strip().upper():c for c in df.columns}
    sym_col=cols.get("SYMBOL"); series_col=cols.get("SERIES")
    if not sym_col: raise ValueError("NSE equity file did not contain SYMBOL")
    if series_col: df=df[df[series_col].astype(str).str.upper().eq("EQ")]
    vals=sorted(set(str(x).strip().upper()+".NS" for x in df[sym_col].dropna() if str(x).strip()))
    pd.DataFrame({"symbol":[x.replace(".NS","") for x in vals]}).to_csv(path,index=False)
    return vals

def load_universe(path: str | None = None, auto: bool = False) -> List[str]:
    if auto:
        try: return refresh_nse_universe()
        except Exception as e:
            if UNIVERSE_CACHE.exists():
                print(f"[universe-fallback] {e}; using cached {UNIVERSE_CACHE}")
                path=str(UNIVERSE_CACHE)
            else: raise
    if not path: path=str(UNIVERSE_CACHE)
    df=pd.read_csv(path)
    if df.empty: return []
    col=next((c for c in df.columns if c.lower() in {"symbol","ticker","scrip"}), df.columns[0])
    vals=[]
    for s in df[col].dropna().astype(str):
        s=s.strip().upper()
        if s and not s.endswith(".NS"): s += ".NS"
        if s: vals.append(s)
    return sorted(set(vals))

def market_regime(cfg: Config) -> dict:
    try:
        df=load_symbol("^NSEI",cfg,period="1y",min_rows=120)
        x=make_features(df); last=x.iloc[-1]
        r20=float(last["ret_20"]); vol20=float(last["vol_20"]); trend=float(last["trend_strength"])
        if trend>.35 and r20>.03: regime="BULLISH"
        elif trend<-.35 and r20<-.03: regime="BEARISH"
        elif vol20>.018: regime="HIGH_VOLATILITY / MIXED"
        else: regime="SIDEWAYS / MIXED"
        return {"regime":regime,"nifty_close":float(df["close"].iloc[-1]),"ret20":r20,"vol20":vol20,"trend_strength":trend,"as_of":str(df.index[-1].date())}
    except Exception as e:
        return {"regime":"UNKNOWN","reason":str(e)}

def rsi(series,n=14):
    delta=series.diff(); up=delta.clip(lower=0).rolling(n).mean(); down=(-delta.clip(upper=0)).rolling(n).mean(); rs=up/down.replace(0,np.nan)
    return 100-(100/(1+rs))

def atr(df,n=14):
    prev=df["close"].shift(1)
    tr=pd.concat([df["high"]-df["low"],(df["high"]-prev).abs(),(df["low"]-prev).abs()],axis=1).max(axis=1)
    return tr.rolling(n).mean()

def make_features(df):
    x=df.copy(); pc=x["close"].shift(1)
    x["ret1"]=x["close"].pct_change(); x["gap"]=x["open"]/pc-1; x["range"]=(x["high"]-x["low"])/pc; x["body"]=(x["close"]-x["open"])/pc
    x["upper_wick"]=(x["high"]-x[["open","close"]].max(axis=1))/pc; x["lower_wick"]=(x[["open","close"]].min(axis=1)-x["low"])/pc
    for n in [3,5,10,20,50]:
        x[f"ret_{n}"]=x["close"].pct_change(n); x[f"vol_{n}"]=x["ret1"].rolling(n).std(); x[f"volume_ratio_{n}"]=x["volume"]/x["volume"].rolling(n).median(); x[f"dist_sma_{n}"]=x["close"]/x["close"].rolling(n).mean()-1
    for n in [10,20,50]:
        hi=x["high"].rolling(n).max(); lo=x["low"].rolling(n).min(); x[f"range_pos_{n}"]=(x["close"]-lo)/(hi-lo).replace(0,np.nan)
    a=atr(x,14); x["atr_pct_14"]=a/x["close"]; x["rsi14"]=rsi(x["close"],14); sma50=x["close"].rolling(50).mean(); x["trend_strength"]=(x["close"]-sma50)/a.replace(0,np.nan)
    return x

def make_supervised(df):
    x=make_features(df); ref=x["close"]; y=pd.DataFrame(index=x.index)
    for name,col in [("open_r","open"),("high_r","high"),("low_r","low"),("close_r","close")]: y[name]=x[col].shift(-1)/ref-1
    y["volume_log"]=np.log1p(x["volume"].shift(-1)); y["up"]=(y["close_r"]>0).astype(int)
    return pd.concat([x[FEATURES],y],axis=1).replace([np.inf,-np.inf],np.nan).dropna()

def fit_models(train,cfg):
    require_ml(); models={}
    for target in ["open_r","high_r","low_r","close_r","volume_log"]:
        models[target]=make_pipeline(StandardScaler(),RandomForestRegressor(n_estimators=cfg.rf_trees,min_samples_leaf=5,max_features=.75,random_state=42,n_jobs=-1)).fit(train[FEATURES],train[target])
    models["up"]=make_pipeline(StandardScaler(),RandomForestClassifier(n_estimators=cfg.rf_trees,min_samples_leaf=6,max_features=.75,random_state=42,n_jobs=-1)).fit(train[FEATURES],train["up"])
    return models

def interval_from_residuals(residuals, center, q1,q2,ref_close):
    r=np.asarray(residuals,dtype=float); r=r[np.isfinite(r)]
    if len(r)<20: return None
    return [float(ref_close*(1+center+np.quantile(r,q1))),float(ref_close*(1+center+np.quantile(r,q2)))]

def historical_analogs(train,latest,k):
    scaler=StandardScaler(); X=scaler.fit_transform(train[FEATURES]); q=scaler.transform(latest[FEATURES])[0]; d=np.sqrt(((X-q)**2).mean(axis=1)); idx=np.argsort(d)[:min(k,len(train))]
    a=train.iloc[idx].copy(); a["distance"]=d[idx]; return a

def technical_state(df):
    x=make_features(df); last=x.iloc[-1]; close=float(last["close"]); high20=float(x["high"].tail(20).max()); low20=float(x["low"].tail(20).min()); high50=float(x["high"].tail(50).max()); low50=float(x["low"].tail(50).min())
    breakout_up=close>high20*.998 and last["volume_ratio_20"]>=1.05; breakdown=close<low20*1.002 and last["volume_ratio_20"]>=1.05
    trend="BULLISH" if last["trend_strength"]>.35 else ("BEARISH" if last["trend_strength"]<-.35 else "NEUTRAL")
    structure="20-DAY BREAKOUT / VOLUME CONFIRMATION" if breakout_up else ("20-DAY BREAKDOWN / VOLUME CONFIRMATION" if breakdown else ("UPPER-RANGE PRESSURE" if last["range_pos_20"]>.75 else ("LOWER-RANGE PRESSURE" if last["range_pos_20"]<.25 else "INSIDE-RANGE / BALANCED")))
    piv_hi=x["high"].rolling(5,center=True).max(); piv_lo=x["low"].rolling(5,center=True).min()
    return {"trend":trend,"structure":structure,"rsi14":round(float(last["rsi14"]),2),"volume_ratio_20":round(float(last["volume_ratio_20"]),2),"range_position_20":round(float(last["range_pos_20"]),3),"recent_20_high":high20,"recent_20_low":low20,"recent_50_high":high50,"recent_50_low":low50,"recent_pivot_highs":[round(float(v),2) for v in x.loc[piv_hi==x["high"],"high"].dropna().tail(3)],"recent_pivot_lows":[round(float(v),2) for v in x.loc[piv_lo==x["low"],"low"].dropna().tail(3)]}

def confluence_score(prob_up,tech):
    p_score=100*max(prob_up,1-prob_up); direction="BULLISH" if prob_up>=.5 else "BEARISH"; score=.60*p_score; bonus=0
    if direction=="BULLISH" and tech["trend"]=="BULLISH": bonus+=15
    if direction=="BEARISH" and tech["trend"]=="BEARISH": bonus+=15
    if direction=="BULLISH" and "BREAKOUT" in tech["structure"]: bonus+=12
    if direction=="BEARISH" and "BREAKDOWN" in tech["structure"]: bonus+=12
    if 45<=tech["rsi14"]<=70 and direction=="BULLISH": bonus+=5
    if 30<=tech["rsi14"]<=55 and direction=="BEARISH": bonus+=5
    if tech["rsi14"]>78 and direction=="BULLISH": bonus-=8
    if tech["rsi14"]<22 and direction=="BEARISH": bonus-=8
    score=max(0,min(100,score+bonus)); label="HIGH" if score>=75 else ("MEDIUM" if score>=60 else "LOW")
    return round(score,1),label

def out_of_sample_residuals(train,cfg):
    """Temporal calibration residuals: fit on earlier rows, score a later holdout."""
    n=len(train); cal_n=max(cfg.calibration_min,int(n*cfg.calibration_fraction))
    if n-cal_n<cfg.min_train or cal_n<20: return {}
    base=train.iloc[:-cal_n].copy(); cal=train.iloc[-cal_n:].copy(); models=fit_models(base,cfg)
    out={}
    for target in ["open_r","high_r","low_r","close_r","volume_log"]:
        pred=models[target].predict(cal[FEATURES]); out[target]=cal[target].to_numpy()-pred
    return out

def forecast_one(symbol,df,cfg):
    sup=make_supervised(df)
    if len(sup)<cfg.min_train: raise ValueError(f"{symbol}: insufficient clean training rows")
    # CRITICAL T+1 ALIGNMENT: train only on rows whose next-session outcome is known;
    # use the actual latest session's feature row as the forecast state.
    train=sup.copy(); latest_features=make_features(df).iloc[[-1]].replace([np.inf,-np.inf],np.nan)
    latest_features=latest_features.dropna(subset=FEATURES)
    if latest_features.empty: raise ValueError(f"{symbol}: latest feature row incomplete")
    models=fit_models(train,cfg); ref_close=float(df["close"].iloc[-1]); point={}
    for target,label in [("open_r","open"),("high_r","high"),("low_r","low"),("close_r","close")]: point[label]=ref_close*(1+float(models[target].predict(latest_features[FEATURES])[0]))
    point["volume"]=float(np.expm1(models["volume_log"].predict(latest_features[FEATURES])[0]))
    cal_res=out_of_sample_residuals(train,cfg); intervals={}
    for target,label in [("open_r","open"),("high_r","high"),("low_r","low"),("close_r","close")]:
        center=point[label]/ref_close-1; r=cal_res.get(target,np.array([])); intervals[label]={"50":interval_from_residuals(r,center,.25,.75,ref_close),"80":interval_from_residuals(r,center,.10,.90,ref_close)}
    vr=cal_res.get("volume_log",np.array([])); vc=np.log1p(point["volume"]); intervals["volume"]={"50":[float(np.expm1(vc+np.quantile(vr,.25))),float(np.expm1(vc+np.quantile(vr,.75)))] if len(vr)>=20 else None,"80":[float(np.expm1(vc+np.quantile(vr,.10))),float(np.expm1(vc+np.quantile(vr,.90)))] if len(vr)>=20 else None}
    p_model=float(models["up"].predict_proba(latest_features[FEATURES])[0][1]); analog=historical_analogs(train,latest_features,cfg.analog_k); p_analog=float(analog["up"].mean()); p_up=.65*p_model+.35*p_analog
    tech=technical_state(df); score,confidence=confluence_score(p_up,tech)
    if p_up>=.58: primary="BULLISH CONTINUATION / DEMAND DEFENSE"; probs=[p_up,(1-p_up)*.65,(1-p_up)*.35]
    elif p_up<=.42: primary="BEARISH CONTINUATION / SUPPLY REJECTION"; probs=[1-p_up,p_up*.65,p_up*.35]
    else: primary="BALANCED / INSIDE-RANGE REGIME"; probs=[.45,.35,.20]
    total=sum(probs); probs=[100*p/total for p in probs]; r20h=tech["recent_20_high"]; r20l=tech["recent_20_low"]; prior=ref_close
    scenarios=[
      {"name":"A","probability":round(probs[0],1),"type":primary,"trigger":f"Acceptance in forecast direction; key reference {r20h if p_up>=.5 else r20l:.2f}.","invalidation":f"Failure through opposite 20-day boundary {r20l if p_up>=.5 else r20h:.2f}."},
      {"name":"B","probability":round(probs[1],1),"type":"RELIEF BOUNCE / FAILED CONTINUATION" if p_up<.5 else "PULLBACK / FAILED CONTINUATION","trigger":f"Rejection of primary direction and reclaim/loss of {prior:.2f}.","invalidation":"Scenario ends if price accepts beyond the primary trigger."},
      {"name":"C","probability":round(probs[2],1),"type":"INSIDE-RANGE CONSOLIDATION","trigger":f"Price remains between {r20l:.2f} and {r20h:.2f}.","invalidation":"Confirmed range expansion."}]
    target_date=(df.index[-1]+pd.tseries.offsets.BDay(1)).date()
    return {"symbol":symbol,"as_of":str(df.index[-1].date()),"target_date":str(target_date),"reference_close":round(ref_close,2),"forecast":{k:round(float(v),2) for k,v in point.items()},"ranges":{k:{"50":[round(v,2) for v in val["50"]] if val["50"] else None,"80":[round(v,2) for v in val["80"]] if val["80"] else None} for k,val in intervals.items()},"probability_up_model":round(p_model,4),"probability_up_analog":round(p_analog,4),"probability_up_blended":round(p_up,4),"probability_status":"MODEL ESTIMATE — NOT CALIBRATED","bias":primary,"confluence_score":score,"confidence_band":confidence,"technical_state":tech,"analog_count":len(analog),"analog_median_close_move":round(float(analog["close_r"].median()),5),"scenarios":scenarios}

def scan_universe(universe,cfg,regime=None):
    rows=[];
    try: prefetch=prefetch_universe_scan_data(universe,cfg); print(f"[data-prefetch] {prefetch}")
    except Exception as e: print(f"[data-prefetch-warning] {e}")
    regime=(regime or {}).get("regime","UNKNOWN")
    for n,symbol in enumerate(universe,1):
        try:
            df=load_symbol(symbol,cfg,period=cfg.scan_history_period,min_rows=cfg.min_scan_history)
            x=make_features(df); last=x.iloc[-1]; tech=technical_state(df); momentum=float(last["ret_20"]); vol=float(last["volume_ratio_20"]); rp=float(last["range_pos_20"]); turnover=float((df["close"]*df["volume"]).tail(20).median()/1e7)
            if not np.isfinite(turnover) or turnover<cfg.min_avg_turnover_crore: continue
            quality=min(15,max(0,math.log10(max(turnover,1))*5)); momentum_score=min(20,max(-20,momentum*120)); volume_score=min(15,max(-5,(vol-1)*15)); structure_score=7 if rp>.8 or rp<.2 else 0; trend_score=8 if tech["trend"]!="NEUTRAL" else 2
            regime_bonus=0
            if regime=="BULLISH" and tech["trend"]=="BULLISH": regime_bonus=5
            elif regime=="BEARISH" and tech["trend"]=="BEARISH": regime_bonus=5
            elif regime.startswith("HIGH_VOLATILITY") and abs(momentum)>.03: regime_bonus=4
            score=50+quality+momentum_score+volume_score+structure_score+trend_score+regime_bonus
            rows.append({"symbol":symbol,"pre_score":round(score,2),"trend":tech["trend"],"structure":tech["structure"],"volume_ratio_20":round(vol,2),"ret20":round(momentum,4),"range_pos20":round(rp,3),"median_turnover_crore":round(turnover,2)})
        except Exception as e: print(f"[skip {n}/{len(universe)}] {symbol}: {e}")
    return pd.DataFrame(rows).sort_values(["pre_score","median_turnover_crore"],ascending=False).reset_index(drop=True) if rows else pd.DataFrame()

def detailed_scan(universe,cfg):
    regime=market_regime(cfg); pre=scan_universe(universe,cfg,regime)
    if pre.empty: return {"run_date":str(pd.Timestamp.now().date()),"universe_size":len(universe),"candidates":[],"market_regime":regime,"message":"No valid symbols/data."}
    shortlist=pre.head(cfg.scan_top_n)["symbol"].tolist(); forecasts=[]
    for symbol in shortlist:
        try: forecasts.append(forecast_one(symbol,load_symbol(symbol,cfg,period=cfg.history_period,min_rows=cfg.min_history),cfg))
        except Exception as e: print(f"[forecast-skip] {symbol}: {e}")
    forecasts=sorted(forecasts,key=lambda z:(z["confluence_score"],max(z["probability_up_blended"],1-z["probability_up_blended"])),reverse=True)[:cfg.final_top_n]
    return {"run_date":str(pd.Timestamp.now().date()),"universe_size":len(universe),"pre_screened":len(shortlist),"final_candidates":len(forecasts),"market_regime":regime,"scanner_summary":pre.head(cfg.scan_top_n).to_dict(orient="records"),"candidates":forecasts}

def range_hit(actual,interval): return None if not interval else bool(interval[0]<=actual<=interval[1])

def walk_forward(symbol,df,cfg):
    sup=make_supervised(df); results=[]
    for i in range(cfg.backtest_start,len(sup)):
        train=sup.iloc[:i].copy(); test=sup.iloc[i:i+1]
        if len(train)<cfg.min_train: continue
        models=fit_models(train,cfg); ref_close=float(df.loc[test.index[0],"close"]); target_pos=df.index.get_loc(test.index[0])+1
        if target_pos>=len(df): continue
        actual=df.iloc[target_pos]; pred_r=float(models["close_r"].predict(test[FEATURES])[0]); pred_close=ref_close*(1+pred_r); pred_up=float(models["up"].predict_proba(test[FEATURES])[0][1]); cal=out_of_sample_residuals(train,cfg); i50=interval_from_residuals(cal.get("close_r",[]),pred_r,.25,.75,ref_close); i80=interval_from_residuals(cal.get("close_r",[]),pred_r,.10,.90,ref_close); actual_close=float(actual["close"]); actual_up=actual_close>ref_close
        results.append({"forecast_date":str(test.index[0].date()),"target_date":str(actual.name.date()),"direction_correct":bool((pred_up>=.5)==actual_up),"close_abs_pct_error":abs(pred_r-(actual_close/ref_close-1)),"close_50_hit":range_hit(actual_close,i50),"close_80_hit":range_hit(actual_close,i80)})
    r=pd.DataFrame(results)
    if r.empty:return {"symbol":symbol,"n":0,"results":[]}
    return {"symbol":symbol,"n":len(r),"direction_accuracy":round(float(r.direction_correct.mean()),4),"median_close_abs_pct_error":round(float(r.close_abs_pct_error.median()),5),"mean_close_abs_pct_error":round(float(r.close_abs_pct_error.mean()),5),"50pct_range_coverage":round(float(r.close_50_hit.dropna().mean()),4),"80pct_range_coverage":round(float(r.close_80_hit.dropna().mean()),4),"results":r.to_dict(orient="records"),"note":"Intervals are temporal-calibration estimates; coverage should converge toward 50%/80% over sufficient out-of-sample evidence."}

def ensure_ledger():
    if not LEDGER.exists():
        pd.DataFrame(columns=LEDGER_COLUMNS).to_csv(LEDGER,index=False)

def flatten_range(ranges,key,q):
    v=ranges.get(key,{}).get(q); return (v or [None,None])

def append_forecasts(result):
    ensure_ledger(); rows=[]
    for symbol,f in result.items() if isinstance(result,dict) else []:
        if not isinstance(f,dict) or "forecast" not in f: continue
        fid=f"{f['as_of']}_{f['target_date']}_{symbol}"
        row={c:"" for c in LEDGER_COLUMNS}; row.update({"forecast_id":fid,"forecast_date":f["as_of"],"target_date":f["target_date"],"symbol":symbol,"reference_close":f["reference_close"],"pred_open":f["forecast"]["open"],"pred_high":f["forecast"]["high"],"pred_low":f["forecast"]["low"],"pred_close":f["forecast"]["close"],"pred_volume":f["forecast"]["volume"],"up_probability_model":f["probability_up_model"],"up_probability_analog":f["probability_up_analog"],"up_probability_estimate":f["probability_up_blended"],"down_probability_estimate":1-f["probability_up_blended"],"probability_status":f["probability_status"],"primary_bias":f["bias"],"confluence_score":f["confluence_score"],"confidence_band":f["confidence_band"],"analog_count":f["analog_count"],"technical_state_json":json.dumps(f["technical_state"]),"scenarios_json":json.dumps(f["scenarios"])} )
        for key in ["open","high","low","close","volume"]:
            for q in ["50","80"]:
                lo,hi=flatten_range(f["ranges"],key,q); row[f"{key}_{q}_low"]=lo; row[f"{key}_{q}_high"]=hi
        rows.append(row)
    if not rows:return
    old=pd.read_csv(LEDGER,dtype=str) if LEDGER.exists() and LEDGER.stat().st_size else pd.DataFrame(columns=LEDGER_COLUMNS)
    new=pd.DataFrame(rows); combined=pd.concat([old,new],ignore_index=True)
    combined=combined.drop_duplicates(subset=["forecast_id"],keep="last"); combined.to_csv(LEDGER,index=False)

def score_ledger(cfg, symbols=None):
    ensure_ledger(); led=pd.read_csv(LEDGER,dtype=str)
    if led.empty:return {"scored":0,"message":"Ledger is empty."}
    targets=set(s.upper() if s.upper().endswith('.NS') else s.upper()+'.NS' for s in symbols) if symbols else None; scored=0
    for i,row in led.iterrows():
        if str(row.get("actual_close","")) not in ("","nan"): continue
        if targets and row.symbol.upper() not in targets: continue
        try:
            df=load_symbol(row.symbol,cfg); target=pd.Timestamp(row.target_date)
            if target not in df.index: continue
            a=df.loc[target]; ref=float(row.reference_close); pc=float(row.pred_close); po=float(row.pred_open); ph=float(row.pred_high); pl=float(row.pred_low); pv=float(row.pred_volume)
            actual_close=float(a.close); direction=("UP" if actual_close>ref else "DOWN" if actual_close<ref else "FLAT"); pred_dir="UP" if float(row.up_probability_estimate)>=.5 else "DOWN"
            c50=[float(row.close_50_low),float(row.close_50_high)] if row.close_50_low not in ("","nan") else None; c80=[float(row.close_80_low),float(row.close_80_high)] if row.close_80_low not in ("","nan") else None
            # Scenario classification is deliberately conservative: A if direction agrees with primary directional bias,
            # C if close remains within 20D reference range, otherwise B. This is a scoring label, not a new prediction.
            tech=json.loads(row.technical_state_json); scenarios=json.loads(row.scenarios_json); low20=float(tech["recent_20_low"]); high20=float(tech["recent_20_high"])
            primary_dir="UP" if "BULLISH" in row.primary_bias else "DOWN" if "BEARISH" in row.primary_bias else "FLAT"
            scenario="A" if primary_dir==direction else ("C" if low20<=actual_close<=high20 else "B")
            if direction!=pred_dir: failure="wrong direction"
            elif c80 and not (c80[0]<=actual_close<=c80[1]): failure="range miss / magnitude error"
            elif abs(actual_close/ref-1)>.02 and abs(pc/ref-1)<.01: failure="magnitude underestimation"
            else: failure="none"
            vals={"actual_open":a.open,"actual_high":a.high,"actual_low":a.low,"actual_close":a.close,"actual_volume":a.volume,"direction_result":direction,"open_error_pct":abs(po-float(a.open))/ref,"high_error_pct":abs(ph-float(a.high))/ref,"low_error_pct":abs(pl-float(a.low))/ref,"close_error_pct":abs(pc-actual_close)/ref,"volume_error_pct":abs(pv-float(a.volume))/max(float(a.volume),1),"close_50_hit":range_hit(actual_close,c50),"close_80_hit":range_hit(actual_close,c80),"scenario_result":scenario,"failure_classification":failure,"scored_at":str(pd.Timestamp.now())}
            for k,v in vals.items(): led.at[i,k]=v
            scored+=1
        except Exception as e: print(f"[score-skip] {row.symbol}: {e}")
    led.to_csv(LEDGER,index=False); return {"scored":scored,"ledger_rows":len(led)}

def save_backtest(result): BACKTEST_RESULTS.write_text(json.dumps(result,indent=2),encoding="utf-8")

def print_forecast(f):
    print("\n"+"="*78); print(f"T+1 FORECAST — {f['symbol']} | AS OF {f['as_of']} | TARGET {f['target_date']}"); print("="*78)
    print(f"Reference close: {f['reference_close']} | Bias: {f['bias']} | Confluence: {f['confluence_score']}/100 ({f['confidence_band']})")
    print(f"Up estimate: {100*f['probability_up_blended']:.1f}% | Down estimate: {100*(1-f['probability_up_blended']):.1f}% | {f['probability_status']}")
    for k in ["open","high","low","close","volume"]: print(f"{k.upper():<8} {f['forecast'][k]:>12.2f} | 50% {f['ranges'][k]['50']} | 80% {f['ranges'][k]['80']}")
    t=f['technical_state']; print(f"Technical: {t['trend']} | {t['structure']} | RSI {t['rsi14']} | Vol {t['volume_ratio_20']}x")
    print("Scenarios:"); [print(f"  {s['name']}: {s['probability']}% — {s['type']} | Trigger: {s['trigger']} | Invalidation: {s['invalidation']}") for s in f['scenarios']]

def main():
    p=argparse.ArgumentParser(description="BULL & CREST T+1 Market Forecast System"); sub=p.add_subparsers(dest="mode",required=True)
    p.add_argument("--config",default=str(CONFIG_FILE),help="Path to T1 forecast config JSON"); s=sub.add_parser("scan"); s.add_argument("--universe",default=str(ROOT/"universe_template.csv")); s.add_argument("--auto-universe",action="store_true",help="Refresh the official NSE EQ universe before scanning"); s.add_argument("--refresh-data",action="store_true",help="Refresh market-data cache before running"); s.add_argument("--out",default="t1_scan.json"); s.add_argument("--record-ledger",action="store_true")
    f=sub.add_parser("forecast"); f.add_argument("--symbols",required=True); f.add_argument("--out",default="t1_forecasts.json"); f.add_argument("--record-ledger",action="store_true")
    b=sub.add_parser("backtest"); b.add_argument("--symbol",required=True); b.add_argument("--out",default=str(BACKTEST_RESULTS))
    sc=sub.add_parser("score"); sc.add_argument("--symbols",default="")
    a=sub.add_parser("auto-scan",help="Refresh NSE EQ universe, scan, forecast, and record ledger"); a.add_argument("--out",default="t1_daily_run.json"); a.add_argument("--refresh-data",action="store_true",help="Refresh market-data cache before running")
    args=p.parse_args(); cfg=load_config(Path(getattr(args,"config",CONFIG_FILE))); cfg.refresh_data=getattr(args,"refresh_data",False)
    if args.mode=="auto-scan":
        universe=load_universe(auto=True); result=detailed_scan(universe,cfg); Path(args.out).write_text(json.dumps(result,indent=2),encoding="utf-8"); append_forecasts({x["symbol"]:x for x in result.get("candidates",[])}); RUN_STATUS.write_text(json.dumps({"status":"completed","run_at":str(pd.Timestamp.now()),"universe_size":len(universe),"final_candidates":result.get("final_candidates",0),"market_regime":result.get("market_regime")},indent=2),encoding="utf-8"); print(json.dumps({"status":"completed","universe_size":len(universe),"final_candidates":result.get("final_candidates",0)},indent=2))
    elif args.mode=="scan":
        universe=load_universe(None if args.auto_universe else args.universe,auto=args.auto_universe); result=detailed_scan(universe,cfg); Path(args.out).write_text(json.dumps(result,indent=2),encoding="utf-8");
        if args.record_ledger: append_forecasts({x["symbol"]:x for x in result.get("candidates",[])})
        print(json.dumps({"universe_size":result.get("universe_size"),"final_candidates":result.get("final_candidates"),"candidates":[{"symbol":x["symbol"],"bias":x["bias"],"confluence":x["confluence_score"]} for x in result.get("candidates",[])]},indent=2))
    elif args.mode=="forecast":
        result={}
        for symbol in [x.strip().upper() for x in args.symbols.split(',') if x.strip()]:
            if not symbol.endswith('.NS'): symbol+='.NS'
            try: result[symbol]=forecast_one(symbol,load_symbol(symbol,cfg),cfg); print_forecast(result[symbol])
            except Exception as e: print(f"[error] {symbol}: {e}")
        Path(args.out).write_text(json.dumps(result,indent=2),encoding="utf-8");
        if args.record_ledger: append_forecasts(result)
    elif args.mode=="backtest":
        symbol=args.symbol.upper(); symbol=symbol if symbol.endswith('.NS') else symbol+'.NS'; result=walk_forward(symbol,load_symbol(symbol,cfg),cfg); Path(args.out).write_text(json.dumps(result,indent=2),encoding="utf-8"); save_backtest(result); print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))
    elif args.mode=="score":
        syms=[x.strip() for x in args.symbols.split(',') if x.strip()] if args.symbols else None; print(json.dumps(score_ledger(cfg,syms),indent=2))

if __name__=="__main__": main()
