#!/usr/bin/env python3
"""
BULL & CREST — T+1 MARKET FORECAST SYSTEM v2.0
Scanner -> Statistical Forecast -> Technical Confluence -> Scenarios -> Validation

This is a research engine, not a guarantee or trading signal.

Recommended data:
- Daily OHLCV
- 250+ sessions per symbol
- NSE symbols in Yahoo Finance format, e.g. RELIANCE.NS

Modes:
1) scan: scan a universe and rank candidates
2) forecast: detailed T+1 forecast for selected symbols
3) backtest: walk-forward validation for one symbol

Examples:
    python t1_market_forecast_final.py scan --universe universe.csv
    python t1_market_forecast_final.py forecast --symbols PRICOLLTD.NS,MOPE.L
    python t1_market_forecast_final.py backtest --symbol PRICOLLTD.NS
"""

from __future__ import annotations
import argparse
import json
import math
import os
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

try:
    import yfinance as yf
except ImportError:
    yf = None

try:
    from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
except ImportError:
    RandomForestRegressor = RandomForestClassifier = None


# -----------------------------
# Configuration
# -----------------------------

@dataclass
class Config:
    history_period: str = "3y"
    min_history: int = 250
    scan_top_n: int = 20
    final_top_n: int = 8
    analog_k: int = 40
    rf_trees: int = 350
    min_train: int = 160
    backtest_start: int = 180


FEATURES = [
    "ret1", "gap", "range", "body", "upper_wick", "lower_wick",
    "ret_3", "ret_5", "ret_10", "ret_20", "ret_50",
    "vol_5", "vol_10", "vol_20", "vol_50",
    "volume_ratio_5", "volume_ratio_10", "volume_ratio_20", "volume_ratio_50",
    "dist_sma_5", "dist_sma_10", "dist_sma_20", "dist_sma_50",
    "range_pos_10", "range_pos_20", "range_pos_50",
    "atr_pct_14", "rsi14", "trend_strength",
]


# -----------------------------
# Data
# -----------------------------

def require_ml():
    if RandomForestRegressor is None:
        raise RuntimeError("Install dependencies first: pip install pandas numpy scikit-learn yfinance")


def load_symbol(symbol: str, cfg: Config) -> pd.DataFrame:
    if yf is None:
        raise RuntimeError("Install yfinance: pip install yfinance")

    df = yf.download(
        symbol,
        period=cfg.history_period,
        interval="1d",
        auto_adjust=False,
        progress=False,
        threads=False,
    )
    if df is None or df.empty:
        raise ValueError(f"No data returned for {symbol}")

    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    df = df.rename(columns={c: str(c).lower() for c in df.columns})
    needed = ["open", "high", "low", "close", "volume"]
    df = df[[c for c in needed if c in df.columns]].copy()
    for c in needed:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna()
    df.index = pd.to_datetime(df.index).tz_localize(None)
    df = df[~df.index.duplicated(keep="last")].sort_index()

    if len(df) < cfg.min_history:
        raise ValueError(f"{symbol}: only {len(df)} sessions; need at least {cfg.min_history}")
    return df


def load_universe(path: str) -> List[str]:
    df = pd.read_csv(path)
    col = next((c for c in df.columns if c.lower() in {"symbol", "ticker", "scrip"}), df.columns[0])
    vals = []
    for s in df[col].dropna().astype(str):
        s = s.strip().upper()
        if not s:
            continue
        if not s.endswith(".NS"):
            s += ".NS"
        vals.append(s)
    return sorted(set(vals))


# -----------------------------
# Features
# -----------------------------

def rsi(series: pd.Series, n=14):
    delta = series.diff()
    up = delta.clip(lower=0).rolling(n).mean()
    down = (-delta.clip(upper=0)).rolling(n).mean()
    rs = up / down.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def atr(df: pd.DataFrame, n=14):
    prev = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"] - prev).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(n).mean()


def make_features(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    pc = x["close"].shift(1)

    x["ret1"] = x["close"].pct_change()
    x["gap"] = x["open"] / pc - 1
    x["range"] = (x["high"] - x["low"]) / pc
    x["body"] = (x["close"] - x["open"]) / pc
    x["upper_wick"] = (x["high"] - x[["open", "close"]].max(axis=1)) / pc
    x["lower_wick"] = (x[["open", "close"]].min(axis=1) - x["low"]) / pc

    for n in [3, 5, 10, 20, 50]:
        x[f"ret_{n}"] = x["close"].pct_change(n)
        x[f"vol_{n}"] = x["ret1"].rolling(n).std()
        x[f"volume_ratio_{n}"] = x["volume"] / x["volume"].rolling(n).median()
        x[f"dist_sma_{n}"] = x["close"] / x["close"].rolling(n).mean() - 1

    for n in [10, 20, 50]:
        hi = x["high"].rolling(n).max()
        lo = x["low"].rolling(n).min()
        x[f"range_pos_{n}"] = (x["close"] - lo) / (hi - lo).replace(0, np.nan)

    a = atr(x, 14)
    x["atr_pct_14"] = a / x["close"]
    x["rsi14"] = rsi(x["close"], 14)

    # Trend strength: distance from 50-SMA scaled by ATR.
    sma50 = x["close"].rolling(50).mean()
    x["trend_strength"] = (x["close"] - sma50) / a.replace(0, np.nan)

    return x


def make_supervised(df: pd.DataFrame) -> pd.DataFrame:
    x = make_features(df)
    ref = x["close"]

    y = pd.DataFrame(index=x.index)
    for name, col in [
        ("open_r", "open"), ("high_r", "high"),
        ("low_r", "low"), ("close_r", "close")
    ]:
        y[name] = x[col].shift(-1) / ref - 1
    y["volume_log"] = np.log1p(x["volume"].shift(-1))
    y["up"] = (y["close_r"] > 0).astype(int)

    z = pd.concat([x[FEATURES], y], axis=1)
    z = z.replace([np.inf, -np.inf], np.nan).dropna()
    return z


# -----------------------------
# Statistical model
# -----------------------------

def fit_models(train: pd.DataFrame, cfg: Config):
    require_ml()
    models = {}

    for target in ["open_r", "high_r", "low_r", "close_r", "volume_log"]:
        model = make_pipeline(
            StandardScaler(),
            RandomForestRegressor(
                n_estimators=cfg.rf_trees,
                min_samples_leaf=5,
                max_features=0.75,
                random_state=42,
                n_jobs=-1,
            ),
        )
        model.fit(train[FEATURES], train[target])
        models[target] = model

    clf = make_pipeline(
        StandardScaler(),
        RandomForestClassifier(
            n_estimators=cfg.rf_trees,
            min_samples_leaf=6,
            max_features=0.75,
            random_state=42,
            n_jobs=-1,
        ),
    )
    clf.fit(train[FEATURES], train["up"])
    models["up"] = clf
    return models


def quantile_interval(residuals, center, q1, q2, ref_close):
    r = np.asarray(residuals, dtype=float)
    r = r[np.isfinite(r)]
    if len(r) < 50:
        return None
    return [
        float(ref_close * (1 + center + np.quantile(r, q1))),
        float(ref_close * (1 + center + np.quantile(r, q2))),
    ]


def historical_analogs(train: pd.DataFrame, latest: pd.DataFrame, k: int):
    scaler = StandardScaler()
    X = scaler.fit_transform(train[FEATURES])
    q = scaler.transform(latest[FEATURES])[0]
    d = np.sqrt(((X - q) ** 2).mean(axis=1))
    idx = np.argsort(d)[:min(k, len(train))]
    a = train.iloc[idx].copy()
    a["distance"] = d[idx]
    return a


# -----------------------------
# Technical / market-structure layer
# -----------------------------

def technical_state(df: pd.DataFrame) -> Dict:
    x = make_features(df)
    last = x.iloc[-1]
    prev = x.iloc[-2]

    close = float(last["close"])
    high20 = float(x["high"].tail(20).max())
    low20 = float(x["low"].tail(20).min())
    high50 = float(x["high"].tail(50).max())
    low50 = float(x["low"].tail(50).min())

    breakout_up = close > high20 * 0.998 and last["volume_ratio_20"] >= 1.05
    breakdown = close < low20 * 1.002 and last["volume_ratio_20"] >= 1.05

    trend = "BULLISH" if last["trend_strength"] > 0.35 else (
        "BEARISH" if last["trend_strength"] < -0.35 else "NEUTRAL"
    )

    if breakout_up:
        structure = "20-DAY BREAKOUT / VOLUME CONFIRMATION"
    elif breakdown:
        structure = "20-DAY BREAKDOWN / VOLUME CONFIRMATION"
    elif last["range_pos_20"] > 0.75:
        structure = "UPPER-RANGE PRESSURE"
    elif last["range_pos_20"] < 0.25:
        structure = "LOWER-RANGE PRESSURE"
    else:
        structure = "INSIDE-RANGE / BALANCED"

    # Recent pivot-like levels: confirmed local extrema.
    piv_hi = x["high"].rolling(5, center=True).max()
    piv_lo = x["low"].rolling(5, center=True).min()
    recent_pivot_high = x.loc[piv_hi == x["high"], "high"].dropna().tail(3).tolist()
    recent_pivot_low = x.loc[piv_lo == x["low"], "low"].dropna().tail(3).tolist()

    return {
        "trend": trend,
        "structure": structure,
        "rsi14": round(float(last["rsi14"]), 2),
        "volume_ratio_20": round(float(last["volume_ratio_20"]), 2),
        "range_position_20": round(float(last["range_pos_20"]), 3),
        "recent_20_high": high20,
        "recent_20_low": low20,
        "recent_50_high": high50,
        "recent_50_low": low50,
        "recent_pivot_highs": [round(float(v), 2) for v in recent_pivot_high],
        "recent_pivot_lows": [round(float(v), 2) for v in recent_pivot_low],
    }


def confluence_score(prob_up: float, tech: Dict) -> Tuple[float, str]:
    # Score is deliberately transparent, not a trading signal.
    p_score = 100 * max(prob_up, 1 - prob_up)
    direction = "BULLISH" if prob_up >= 0.5 else "BEARISH"

    score = 0.60 * p_score
    bonus = 0

    if direction == "BULLISH" and tech["trend"] == "BULLISH":
        bonus += 12
    if direction == "BEARISH" and tech["trend"] == "BEARISH":
        bonus += 12
    if "BREAKOUT" in tech["structure"] and direction == "BULLISH":
        bonus += 8
    if "BREAKDOWN" in tech["structure"] and direction == "BEARISH":
        bonus += 8

    # Extreme RSI reduces blind continuation confidence.
    if direction == "BULLISH" and tech["rsi14"] > 78:
        bonus -= 7
    if direction == "BEARISH" and tech["rsi14"] < 22:
        bonus -= 7

    score = max(0, min(100, score + bonus))
    label = "HIGH" if score >= 72 else ("MEDIUM" if score >= 62 else "LOW")
    return round(score, 1), label


# -----------------------------
# Forecast
# -----------------------------

def forecast_one(symbol: str, df: pd.DataFrame, cfg: Config) -> Dict:
    sup = make_supervised(df)
    if len(sup) < cfg.min_train + 10:
        raise ValueError(f"{symbol}: insufficient clean training rows")

    train = sup.iloc[:-1].copy()
    latest = sup.iloc[-1:]
    models = fit_models(train, cfg)

    ref_close = float(df["close"].iloc[-1])
    point = {}

    for target, label in [
        ("open_r", "open"), ("high_r", "high"),
        ("low_r", "low"), ("close_r", "close")
    ]:
        r = float(models[target].predict(latest[FEATURES])[0])
        point[label] = ref_close * (1 + r)

    point["volume"] = float(np.expm1(models["volume_log"].predict(latest[FEATURES])[0]))

    intervals = {}
    for target, label in [
        ("open_r", "open"), ("high_r", "high"),
        ("low_r", "low"), ("close_r", "close")
    ]:
        pred = models[target].predict(train[FEATURES])
        residuals = train[target].to_numpy() - pred
        center = float(point[label] / ref_close - 1)
        i50 = quantile_interval(residuals, center, 0.25, 0.75, ref_close)
        i80 = quantile_interval(residuals, center, 0.10, 0.90, ref_close)
        intervals[label] = {"50": i50, "80": i80}

    # Volume intervals from historical residuals in log-space.
    vp = models["volume_log"].predict(train[FEATURES])
    vr = train["volume_log"].to_numpy() - vp
    vc = float(np.log1p(point["volume"]))
    intervals["volume"] = {
        "50": [float(np.expm1(vc + np.quantile(vr, .25))),
               float(np.expm1(vc + np.quantile(vr, .75)))],
        "80": [float(np.expm1(vc + np.quantile(vr, .10))),
               float(np.expm1(vc + np.quantile(vr, .90)))],
    }

    p_model = float(models["up"].predict_proba(latest[FEATURES])[0][1])
    analog = historical_analogs(train, latest, cfg.analog_k)
    p_analog = float(analog["up"].mean())

    # Model/analog blend. This is not claimed to be calibrated until backtested.
    p_up = 0.65 * p_model + 0.35 * p_analog

    tech = technical_state(df)
    score, confidence = confluence_score(p_up, tech)

    # Forecast scenarios: probabilities sum to 100 and are tied to the model bias.
    if p_up >= .58:
        primary = "BULLISH CONTINUATION / DEMAND DEFENSE"
        probs = [p_up, (1-p_up)*.65, (1-p_up)*.35]
    elif p_up <= .42:
        primary = "BEARISH CONTINUATION / SUPPLY REJECTION"
        probs = [1-p_up, p_up*.65, p_up*.35]
    else:
        primary = "BALANCED / INSIDE-RANGE REGIME"
        probs = [.45, .35, .20]

    total = sum(probs)
    probs = [100*p/total for p in probs]

    prior_close = float(df["close"].iloc[-1])
    r20h = tech["recent_20_high"]
    r20l = tech["recent_20_low"]

    scenarios = [
        {
            "name": "A",
            "probability": round(probs[0], 1),
            "type": primary,
            "trigger": f"Acceptance in the forecast direction; key reference {r20h if p_up >= .5 else r20l:.2f}.",
            "invalidation": f"Failure through the opposite 20-day boundary {r20l if p_up >= .5 else r20h:.2f}.",
        },
        {
            "name": "B",
            "probability": round(probs[1], 1),
            "type": "RELIEF BOUNCE / FAILED CONTINUATION" if p_up < .5 else "PULLBACK / FAILED CONTINUATION",
            "trigger": f"Rejection of the primary direction and reclaim/loss of {prior_close:.2f}.",
            "invalidation": "Scenario ends if price accepts beyond the primary trigger.",
        },
        {
            "name": "C",
            "probability": round(probs[2], 1),
            "type": "INSIDE-RANGE CONSOLIDATION",
            "trigger": f"Price remains between {r20l:.2f} and {r20h:.2f}.",
            "invalidation": "Confirmed range expansion.",
        },
    ]

    return {
        "symbol": symbol,
        "as_of": str(df.index[-1].date()),
        "reference_close": round(ref_close, 2),
        "forecast": {k: round(float(v), 2) for k, v in point.items()},
        "ranges": {
            k: {
                "50": [round(float(v[0]), 2), round(float(v[1]), 2)] if v["50"] else None,
                "80": [round(float(v[0]), 2), round(float(v[1]), 2)] if v["80"] else None,
            } for k, v in intervals.items()
        },
        "probability_up_model": round(p_model, 4),
        "probability_up_analog": round(p_analog, 4),
        "probability_up_blended": round(p_up, 4),
        "bias": primary,
        "confluence_score": score,
        "confidence_band": confidence,
        "technical_state": tech,
        "analog_count": len(analog),
        "analog_median_close_move": round(float(analog["close_r"].median()), 5),
        "scenarios": scenarios,
    }


# -----------------------------
# Scanner
# -----------------------------

def scan_universe(universe: List[str], cfg: Config) -> pd.DataFrame:
    rows = []
    for n, symbol in enumerate(universe, 1):
        try:
            df = load_symbol(symbol, cfg)
            sup = make_supervised(df)
            if len(sup) < cfg.min_train + 10:
                continue

            tech = technical_state(df)
            # Fast pre-score avoids fitting RF to every stock.
            momentum = float(sup["ret_20"].iloc[-1])
            vol_ratio = float(tech["volume_ratio_20"])
            range_pos = float(tech["range_position_20"])

            # Opportunity score is only a pre-filter, not final probability.
            score = 50
            score += min(15, max(-15, momentum * 100))
            score += min(10, max(-5, (vol_ratio - 1) * 10))
            score += 5 if range_pos > .75 or range_pos < .25 else 0
            score += 0

            rows.append({
                "symbol": symbol,
                "pre_score": round(float(score), 2),
                "trend": tech["trend"],
                "structure": tech["structure"],
                "volume_ratio_20": round(vol_ratio, 2),
                "ret20": round(momentum, 4),
                "range_pos20": round(range_pos, 3),
            })
        except Exception as e:
            print(f"[skip] {symbol}: {e}")

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    return out.sort_values(["pre_score", "volume_ratio_20"], ascending=False).reset_index(drop=True)


def detailed_scan(universe: List[str], cfg: Config) -> Dict:
    pre = scan_universe(universe, cfg)
    if pre.empty:
        return {"candidates": [], "message": "No valid symbols/data."}

    shortlist = pre.head(cfg.scan_top_n)["symbol"].tolist()
    forecasts = []

    for symbol in shortlist:
        try:
            df = load_symbol(symbol, cfg)
            f = forecast_one(symbol, df, cfg)
            forecasts.append(f)
            print(f"[forecast] {symbol}: {f['bias']} | score={f['confluence_score']}")
        except Exception as e:
            print(f"[forecast-skip] {symbol}: {e}")

    forecasts = sorted(
        forecasts,
        key=lambda z: (z["confluence_score"], max(z["probability_up_blended"], 1-z["probability_up_blended"])),
        reverse=True,
    )[:cfg.final_top_n]

    return {
        "run_date": str(pd.Timestamp.now().date()),
        "universe_size": len(universe),
        "pre_screened": len(shortlist),
        "final_candidates": len(forecasts),
        "candidates": forecasts,
    }


# -----------------------------
# Walk-forward validation
# -----------------------------

def range_hit(actual: float, interval):
    if not interval:
        return None
    return interval[0] <= actual <= interval[1]


def walk_forward(symbol: str, df: pd.DataFrame, cfg: Config) -> Dict:
    sup = make_supervised(df)
    results = []

    for i in range(cfg.backtest_start, len(sup)-1):
        train = sup.iloc[:i].copy()
        test = sup.iloc[i:i+1]
        if len(train) < cfg.min_train:
            continue

        models = fit_models(train, cfg)
        ref_close = float(df.loc[test.index[0], "close"])
        actual_idx = test.index[0] + 1
        if actual_idx >= len(df):
            continue
        actual = df.loc[actual_idx]

        pred_close_r = float(models["close_r"].predict(test[FEATURES])[0])
        pred_close = ref_close * (1 + pred_close_r)
        pred_up = float(models["up"].predict_proba(test[FEATURES])[0][1])

        # Out-of-sample residual interval from training only.
        in_pred = models["close_r"].predict(train[FEATURES])
        residuals = train["close_r"].to_numpy() - in_pred
        i50 = quantile_interval(residuals, pred_close_r, .25, .75, ref_close)
        i80 = quantile_interval(residuals, pred_close_r, .10, .90, ref_close)

        actual_close = float(actual["close"])
        actual_up = actual_close > ref_close

        results.append({
            "date": str(actual.name.date()),
            "direction_correct": bool((pred_up >= .5) == actual_up),
            "close_abs_pct_error": abs(pred_close_r - (actual_close/ref_close - 1)),
            "close_50_hit": range_hit(actual_close, i50),
            "close_80_hit": range_hit(actual_close, i80),
        })

    r = pd.DataFrame(results)
    if r.empty:
        return {"symbol": symbol, "n": 0}

    return {
        "symbol": symbol,
        "n": int(len(r)),
        "direction_accuracy": round(float(r["direction_correct"].mean()), 4),
        "median_close_abs_pct_error": round(float(r["close_abs_pct_error"].median()), 5),
        "mean_close_abs_pct_error": round(float(r["close_abs_pct_error"].mean()), 5),
        "50pct_range_coverage": round(float(r["close_50_hit"].mean()), 4),
        "80pct_range_coverage": round(float(r["close_80_hit"].mean()), 4),
        "note": "Coverage should be near 50% / 80% for well-calibrated intervals, not necessarily exactly.",
    }


# -----------------------------
# Output
# -----------------------------

def print_forecast(f: Dict):
    print("\n" + "="*78)
    print(f"T+1 FORECAST — {f['symbol']} | AS OF {f['as_of']}")
    print("="*78)
    print(f"Reference close: {f['reference_close']}")
    print(f"Bias: {f['bias']}")
    print(f"Confluence: {f['confluence_score']}/100 ({f['confidence_band']})")
    print(f"Up probability: {100*f['probability_up_blended']:.1f}%")
    print(f"Down probability: {100*(1-f['probability_up_blended']):.1f}%")
    print("\nMETRIC       ESTIMATE       50% RANGE              80% RANGE")
    for k in ["open", "high", "low", "close", "volume"]:
        est = f["forecast"][k]
        r50 = f["ranges"][k]["50"]
        r80 = f["ranges"][k]["80"]
        print(f"{k.upper():<10} {est:>10.2f}   {str(r50):<23} {r80}")

    t = f["technical_state"]
    print("\nTECHNICAL STATE")
    print(f"Trend: {t['trend']}")
    print(f"Structure: {t['structure']}")
    print(f"RSI14: {t['rsi14']} | Volume ratio: {t['volume_ratio_20']}x")
    print(f"20D range: {t['recent_20_low']:.2f} — {t['recent_20_high']:.2f}")

    print("\nSCENARIOS")
    for s in f["scenarios"]:
        print(f"Scenario {s['name']} — {s['probability']}% — {s['type']}")
        print(f"  Trigger: {s['trigger']}")
        print(f"  Invalidation: {s['invalidation']}")

    print("\nNOTE: Probabilities are model outputs and require ongoing out-of-sample validation.")


def main():
    p = argparse.ArgumentParser(description="BULL & CREST T+1 Market Forecast System")
    sub = p.add_subparsers(dest="mode", required=True)

    s = sub.add_parser("scan")
    s.add_argument("--universe", required=True, help="CSV with symbol/ticker column")
    s.add_argument("--out", default="t1_scan.json")

    f = sub.add_parser("forecast")
    f.add_argument("--symbols", required=True, help="Comma-separated symbols")
    f.add_argument("--out", default="t1_forecasts.json")

    b = sub.add_parser("backtest")
    b.add_argument("--symbol", required=True)
    b.add_argument("--out", default="t1_backtest.json")

    args = p.parse_args()
    cfg = Config()

    if args.mode == "scan":
        universe = load_universe(args.universe)
        result = detailed_scan(universe, cfg)
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"\nSaved {args.out}")
        print("\nFINAL SHORTLIST")
        for i, x in enumerate(result["candidates"], 1):
            print(f"{i}. {x['symbol']} | {x['bias']} | score {x['confluence_score']} | "
                  f"Up {100*x['probability_up_blended']:.1f}%")

    elif args.mode == "forecast":
        result = {}
        for symbol in [x.strip().upper() for x in args.symbols.split(",") if x.strip()]:
            if not symbol.endswith(".NS"):
                symbol += ".NS"
            try:
                df = load_symbol(symbol, cfg)
                result[symbol] = forecast_one(symbol, df, cfg)
                print_forecast(result[symbol])
            except Exception as e:
                print(f"[error] {symbol}: {e}")
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"\nSaved {args.out}")

    elif args.mode == "backtest":
        symbol = args.symbol.upper()
        if not symbol.endswith(".NS"):
            symbol += ".NS"
        df = load_symbol(symbol, cfg)
        result = walk_forward(symbol, df, cfg)
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))
        print(f"\nSaved {args.out}")


if __name__ == "__main__":
    main()
